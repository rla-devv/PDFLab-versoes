<# : Avulso IA - instalador. Este arquivo e ao mesmo tempo .bat (estas linhas) e PowerShell (o resto).
@echo off
rem Tudo automatico e sem precisar de Python no Windows: baixa o Python portatil (python.org) para a pasta
rem python, baixa o Avulso IA mais novo publicado (tudo conferido pelo SHA-256), cria os atalhos e abre o app.
setlocal
cd /d "%~dp0"
set "AVULSOIA_INSTALADOR=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& ([scriptblock]::Create([IO.File]::ReadAllText($env:AVULSOIA_INSTALADOR)))"
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)
start "" "%~dp0python\pythonw.exe" "%~dp0avulsoia.pyw"
timeout /t 6 >nul
exit /b 0
#>
param([switch]$SoFuncoes)

$ProgressPreference = 'SilentlyContinue'   # a barra de progresso deixa o download muito lento no PowerShell 5.1
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$app = Split-Path -Parent $env:AVULSOIA_INSTALADOR
$py = Join-Path $app 'python\python.exe'

# so para os testes: servidores locais no lugar do GitHub e do python.org
$Versoes = 'https://raw.githubusercontent.com/rla-devv/avulsoIA-versoes/main/'
if ($env:AVULSOIA_VERSOES_URL -like 'http://127.0.0.1:*') { $Versoes = $env:AVULSOIA_VERSOES_URL }
$PythonUrl = 'https://www.python.org/ftp/python/3.14.8/'
if ($env:AVULSOIA_PYTHON_URL -like 'http://127.0.0.1:*') { $PythonUrl = $env:AVULSOIA_PYTHON_URL }
$Python = @{ Arquivo = 'python-3.14.8-embed-amd64.zip'; Pth = 'python314._pth'
             Sha256 = 'a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310' }

function Baixar([string]$Url, [string]$Destino, [string]$Erro) {
  try {
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destino -ErrorAction Stop
  } catch {
    Remove-Item $Destino -Force -ErrorAction SilentlyContinue
    throw $Erro
  }
}

function Sha256([string]$Arquivo) { return (Get-FileHash -Algorithm SHA256 $Arquivo).Hash.ToLower() }

function Instalar-Python {
  # Python portatil oficial: fica so dentro da pasta do app (nada e instalado no Windows)
  if (-not [Environment]::Is64BitOperatingSystem) { throw 'O Avulso IA em janela precisa do Windows de 64 bits.' }
  Write-Host ' Baixando o Python portatil (python.org, cerca de 12 MB)...'
  $zip = Join-Path $env:TEMP $Python.Arquivo
  Baixar ($PythonUrl + $Python.Arquivo) $zip 'Nao consegui baixar o Python. Confira se o computador esta conectado a internet.'
  if ((Sha256 $zip) -ne $Python.Sha256) {
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
    throw 'O Python baixado nao confere com o original. Por seguranca, nada foi instalado.'
  }
  $novo = Join-Path $app 'python.novo'
  Remove-Item $novo -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive -Path $zip -DestinationPath $novo -Force
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
  # liga o "import site": sem isso o Python portatil nao enxerga os componentes da janela
  $pth = Join-Path $novo $Python.Pth
  (Get-Content $pth) -replace '^#\s*import site', 'import site' | Set-Content $pth -Encoding ASCII
  Remove-Item (Join-Path $app 'python') -Recurse -Force -ErrorAction SilentlyContinue
  Rename-Item $novo 'python'
}

function Baixar-Programa {
  # o avulsoia.pyw da versao publicada mais nova; ele baixa o resto do app
  Write-Host ' Consultando a versao mais nova do Avulso IA...'
  $json = Join-Path $env:TEMP 'avulsoia-atualizacao.json'
  Baixar ($Versoes + 'atualizacao.json?t=' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) $json 'Nao consegui consultar a versao do Avulso IA. Confira se o computador esta conectado a internet.'
  try { $m = [IO.File]::ReadAllText($json) | ConvertFrom-Json } catch { $m = $null }
  Remove-Item $json -Force -ErrorAction SilentlyContinue
  $a = $null
  if ($m) { $a = @($m.arquivos | Where-Object { $_.caminho -eq 'avulsoia.pyw' }) | Select-Object -First 1 }
  if (-not $a -or "$($a.origem)" -notmatch '^(versoes|programa/\d+(\.\d+){1,3})/[A-Za-z0-9][A-Za-z0-9_.-]*$' -or
      "$($a.sha256)" -notmatch '^[0-9a-f]{64}$' -or -not ($a.tamanho -is [int] -or $a.tamanho -is [long])) {
    throw 'O aviso de versao publicado esta com formato inesperado. Nada foi instalado.'
  }
  $novo = Join-Path $app 'avulsoia.pyw.novo'
  Baixar ($Versoes + $a.origem) $novo 'Nao consegui baixar o Avulso IA. Confira se o computador esta conectado a internet.'
  if ((Get-Item $novo).Length -ne $a.tamanho -or (Sha256 $novo) -ne $a.sha256) {
    Remove-Item $novo -Force -ErrorAction SilentlyContinue
    throw 'O programa baixado nao confere com o publicado. Por seguranca, nada foi instalado.'
  }
  Move-Item $novo (Join-Path $app 'avulsoia.pyw') -Force
}

function Rodar-Instalacao {
  # o proprio programa termina: pagina e icone, componentes da janela (pywebview) e atalhos
  & $py (Join-Path $app 'avulsoia.pyw') --instalar
  if ($LASTEXITCODE -ne 0) { throw 'A instalacao nao terminou. Veja a mensagem acima.' }
}

function Instalar-App {
  Write-Host ''
  Write-Host ' Instalando o Avulso IA...'
  Write-Host ''
  if (-not (Test-Path $py)) { Instalar-Python }
  if (-not (Test-Path (Join-Path $app 'avulsoia.pyw'))) { Baixar-Programa }
  Rodar-Instalacao
  Write-Host ''
  Write-Host ' O Avulso IA vai abrir agora. Para abrir depois, use o atalho "Abrir o Avulso IA" nesta pasta'
  Write-Host ' ou o atalho "Avulso IA" na Area de Trabalho e no Menu Iniciar.'
}

if ($SoFuncoes) { return }   # os testes carregam so as funcoes

try {
  Instalar-App
  exit 0
} catch {
  Write-Host ''
  Write-Host " $($_.Exception.Message)"
  $pagina = Join-Path $app 'AvulsoIA-editorPDF.html'
  if (Test-Path $pagina) {
    Write-Host ' Enquanto isso, o Avulso IA vai abrir no navegador (funciona igual).'
    Start-Process $pagina
  }
  Write-Host ' Para tentar de novo, rode o instalar.bat outra vez.'
  exit 1
}
