# Cria o atalho do Avulso IA na Area de Trabalho e no Menu Iniciar.
$ErrorActionPreference = 'Stop'
$app = Split-Path -Parent $MyInvocation.MyCommand.Path
$shell = New-Object -ComObject WScript.Shell
foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $atalho = $shell.CreateShortcut((Join-Path $pasta 'Avulso IA.lnk'))
  $atalho.TargetPath = Join-Path $app '.venv\Scripts\pythonw.exe'
  $atalho.Arguments = '"' + (Join-Path $app 'avulsoia.pyw') + '"'
  $atalho.WorkingDirectory = $app
  $atalho.IconLocation = Join-Path $app 'assets\avulsoia.ico'
  $atalho.Description = 'Avulso IA - edicao, organizacao e conversao de PDFs'
  $atalho.Save()
}
Write-Host ' Atalhos criados.'
