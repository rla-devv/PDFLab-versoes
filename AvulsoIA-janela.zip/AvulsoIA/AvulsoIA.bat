@echo off
rem Alternativa ao atalho: abre o Avulso IA na janela propria.
rem Se ainda nao foi instalado, abre a pagina no navegador.
if exist "%~dp0.venv\Scripts\pythonw.exe" (
  start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0avulsoia.pyw" %*
) else (
  start "" "%~dp0AvulsoIA-editorPDF.html"
)
