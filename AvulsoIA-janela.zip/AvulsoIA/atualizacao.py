# Atualização do Avulso IA em janela própria.
#
# Consulta o atualizacao.json do repositório PÚBLICO de versões (rla-devv/avulsoIA-versoes), baixa a página
# nova e, se mudou, o ícone. Confere tamanho, SHA-256 e a versão escrita dentro da página ANTES de gravar
# qualquer coisa; grava em .novo e renomeia; guarda a página anterior em versoes-anteriores/.
#
# Só troca a página (AvulsoIA-editorPDF.html) e o ícone (assets/avulsoia.ico): nunca código Python.
# Nada é enviado: só baixa os arquivos publicados.
import hashlib
import json
import os
import re
import shutil
import urllib.request
from pathlib import Path

BASE = 'https://raw.githubusercontent.com/rla-devv/avulsoIA-versoes/main/'
# só para os testes: aponta para um servidor local no lugar do GitHub
if os.environ.get('AVULSOIA_VERSOES_URL', '').startswith('http://127.0.0.1:'):
    BASE = os.environ['AVULSOIA_VERSOES_URL']

PAGINA = 'AvulsoIA-editorPDF.html'
ICONE = Path('assets') / 'avulsoia.ico'
ANTERIORES = 'versoes-anteriores'

VERSAO = r'\d+(?:\.\d+){1,3}'
RE_ARQUIVO = re.compile(rf'AvulsoIA-{VERSAO}\.html')
RE_ICONE = re.compile(rf'versoes/avulsoia-{VERSAO}\.ico')
RE_VERSAO_PAGINA = re.compile(rf"const APP_VERSION = '({VERSAO})'")
RE_SHA = re.compile(r'[0-9a-f]{64}')
LIMITE_PAGINA = 50 * 1024 * 1024
LIMITE_ICONE = 2 * 1024 * 1024


class ErroAtualizacao(Exception):
    pass


def ver(v):
    return tuple(int(x) for x in v.split('.'))


def versao_instalada(app):
    try:
        texto = (Path(app) / PAGINA).read_text(encoding='utf-8', errors='replace')
    except OSError:
        return '0.0.0'
    m = RE_VERSAO_PAGINA.search(texto)
    return m.group(1) if m else '0.0.0'


def _baixar(caminho, limite):
    req = urllib.request.Request(BASE + caminho, headers={'User-Agent': 'AvulsoIA-janela', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=20) as r:
        dados = r.read(limite + 1)
    if len(dados) > limite:
        raise ErroAtualizacao(f'{caminho} é maior que o permitido')
    return dados


def _arquivo_valido(info, regex, limite):
    return (isinstance(info, dict)
            and isinstance(info.get('arquivo'), str) and regex.fullmatch(info['arquivo'])
            and isinstance(info.get('sha256'), str) and RE_SHA.fullmatch(info['sha256'])
            and isinstance(info.get('tamanho'), int) and 0 < info['tamanho'] <= limite)


def consultar():
    """Lê o atualizacao.json publicado e confere o formato. Levanta erro se algo estiver estranho."""
    try:
        m = json.loads(_baixar('atualizacao.json', 64 * 1024))
    except (OSError, ValueError) as e:
        raise ErroAtualizacao(f'não foi possível consultar as versões ({e})') from e
    if not (isinstance(m, dict) and isinstance(m.get('versao'), str) and re.fullmatch(VERSAO, m['versao'])
            and _arquivo_valido(m, RE_ARQUIVO, LIMITE_PAGINA)
            and isinstance(m.get('novidades', []), list) and all(isinstance(n, str) for n in m.get('novidades', []))):
        raise ErroAtualizacao('o aviso de versão publicado está com formato inesperado')
    if 'icone' in m and not _arquivo_valido(m['icone'], RE_ICONE, LIMITE_ICONE):
        raise ErroAtualizacao('o ícone publicado está com formato inesperado')
    return m


def ha_versao_nova(m, app):
    return ver(m['versao']) > ver(versao_instalada(app))


def _conferir(nome, dados, info):
    if len(dados) != info['tamanho']:
        raise ErroAtualizacao(f'{nome}: tamanho diferente do publicado')
    if hashlib.sha256(dados).hexdigest() != info['sha256']:
        raise ErroAtualizacao(f'{nome}: conteúdo diferente do publicado (SHA-256)')


def _gravar(destino, dados):
    novo = destino.with_name(destino.name + '.novo')
    novo.write_bytes(dados)
    os.replace(novo, destino)   # troca de uma vez: nunca fica um arquivo pela metade


def instalar(m, app):
    """Baixa e confere tudo; só então grava. Devolve a versão instalada."""
    app = Path(app)
    v = m['versao']

    pagina = _baixar('versoes/' + m['arquivo'], m['tamanho'])
    _conferir('página', pagina, m)
    texto = pagina.decode('utf-8', errors='replace')
    if (not texto.lower().startswith('<!doctype html>')
            or f'<span id="app-version">{v}</span>' not in texto
            or f"const APP_VERSION = '{v}'" not in texto):
        raise ErroAtualizacao('a página baixada não é a versão anunciada')

    icone = None
    if m.get('icone'):
        atual = (app / ICONE).read_bytes() if (app / ICONE).exists() else b''
        if hashlib.sha256(atual).hexdigest() != m['icone']['sha256']:
            icone = _baixar(m['icone']['arquivo'], m['icone']['tamanho'])
            _conferir('ícone', icone, m['icone'])
            if not icone.startswith(b'\x00\x00\x01\x00'):
                raise ErroAtualizacao('o ícone baixado não é um arquivo .ico')

    # tudo conferido: guarda a página atual e grava as novas
    anterior = versao_instalada(app)
    if (app / PAGINA).exists():
        (app / ANTERIORES).mkdir(exist_ok=True)
        shutil.copy2(app / PAGINA, app / ANTERIORES / f'AvulsoIA-editorPDF-{anterior}.html')
    _gravar(app / PAGINA, pagina)
    if icone:
        _gravar(app / ICONE, icone)
    return v
