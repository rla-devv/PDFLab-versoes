"""Avulso IA — abre o editor de PDF numa janela própria do Windows.

A interface é a página AvulsoIA-editorPDF.html (um arquivo só, com tudo embutido).
O pywebview a exibe numa janela usando o WebView2, o mesmo componente do Edge
que já vem no Windows 10 e 11.

Como a página não precisa de servidor, ela é aberta direto do disco: nada fica
escutando na rede, nem mesmo em 127.0.0.1.

Atualizações (atualizacao.py): ao abrir e a cada 15 minutos, consulta o repositório
público de versões; havendo versão nova, pergunta numa janela do Windows e só instala
se a pessoa confirmar. A página continua sem acesso à rede: quem baixa é este arquivo.

Uso:
    pythonw avulsoia.pyw              abre na janela própria
    pythonw avulsoia.pyw --navegador  abre no navegador padrão
"""

import ctypes
import logging
import sys
import threading
import time
import traceback
import webbrowser
from html import escape
from pathlib import Path

TITLE = 'Avulso IA — Editor de PDF'
ROOT = Path(__file__).resolve().parent
PAGE = ROOT / 'AvulsoIA-editorPDF.html'
ICON = ROOT / 'assets' / 'avulsoia.ico'
LOG_FILE = ROOT / 'logs' / 'avulsoia.log'
# identidade própria no Windows: a barra de tarefas mostra o ícone do Avulso IA (e não o do Python)
APP_ID = 'RLAdev.AvulsoIA'
INTERVALO_ATUALIZACAO = 15 * 60   # segundos
# guarda as preferências da página (ex.: tema claro/escuro) entre uma abertura e outra
STORAGE_DIR = ROOT / 'dados-janela'

WINDOW = dict(width=1400, height=900, min_size=(1000, 680), background_color='#f2f6f5')

# textos que o próprio pywebview mostra (ex.: janela "Salvar arquivo" dos downloads)
LOCALIZATION = {
    'global.quitConfirmation': 'Deseja mesmo sair?',
    'global.ok': 'OK',
    'global.quit': 'Sair',
    'global.cancel': 'Cancelar',
    'global.saveFile': 'Salvar arquivo',
    'windows.fileFilter.allFiles': 'Todos os arquivos',
    'windows.fileFilter.otherFiles': 'Outros tipos de arquivo',
}

log = logging.getLogger('avulsoia')

sys.path.insert(0, str(ROOT))
import atualizacao  # noqa: E402


def setup_logging():
    LOG_FILE.parent.mkdir(exist_ok=True)
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.INFO,
        format='%(asctime)s %(levelname)s %(name)s: %(message)s',
        encoding='utf-8',
    )
    # o pythonw.exe não tem console: sem isso, qualquer print derrubaria o app
    if sys.stdout is None or sys.stderr is None:
        stream = open(LOG_FILE, 'a', encoding='utf-8', buffering=1)
        sys.stdout = sys.stdout or stream
        sys.stderr = sys.stderr or stream


def open_in_browser():
    log.info('Abrindo no navegador padrão: %s', PAGE)
    webbrowser.open(PAGE.as_uri())


def error_page(title, detail):
    return f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Avulso IA</title>
<style>
body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#f2f6f5;color:#102022;
font:15px/1.6 "Segoe UI",system-ui,sans-serif}}
.box{{max-width:620px;background:#fff;border:1px solid #d9e3e1;border-radius:20px;padding:34px 36px;
box-shadow:0 6px 20px rgba(16,40,34,.08)}}
.logo{{width:44px;height:44px;border-radius:12px;background:#0c7a70;color:#fff;display:grid;place-items:center;
font-weight:800;margin-bottom:16px}}
h1{{margin:0 0 8px;font-size:22px}} p{{margin:0 0 10px;color:#5a6b6d}}
pre{{white-space:pre-wrap;background:#f2f6f5;border-radius:10px;padding:12px;font-size:12.5px;color:#5a6b6d;max-height:220px;overflow:auto}}
</style></head><body><div class="box"><div class="logo">A</div>
<h1>{escape(title)}</h1>
<p>Se o problema continuar, reinstale o Avulso IA pelo <b>instalar.bat</b>.</p>
<p>Detalhes técnicos (também salvos em <b>logs\\avulsoia.log</b>):</p>
<pre>{escape(detail)}</pre></div></body></html>"""


def identidade_windows():
    if sys.platform != 'win32':
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        log.exception('Não foi possível definir a identidade do app no Windows')


def recarregar_icones_do_windows():
    # o ícone do atalho pode ter mudado com a atualização; avisa o Windows para redesenhar
    if sys.platform != 'win32':
        return
    try:
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
    except Exception:
        log.exception('Não foi possível recarregar os ícones')


class Atualizador:
    """Consulta e instala atualizações. Nunca instala sem a pessoa confirmar."""

    def __init__(self):
        self.janela = None
        self.trava = threading.Lock()
        self.adiada = None   # versão que a pessoa deixou para depois (não pergunta de novo sozinho)

    def ocupada(self):
        # não interrompe quem está no meio de uma tarefa (a página informa)
        try:
            return bool(self.janela.evaluate_js('!!(window.avulsoOcupado && window.avulsoOcupado())'))
        except Exception:
            return False

    def verificar(self, manual=False):
        if not self.trava.acquire(blocking=False):
            return {'estado': 'ocupado'}
        try:
            try:
                m = atualizacao.consultar()
            except atualizacao.ErroAtualizacao as e:
                log.warning('Consulta de atualização: %s', e)
                return {'estado': 'erro', 'mensagem': 'Não foi possível verificar agora. Confira a conexão com a internet.'}
            atual = atualizacao.versao_instalada(ROOT)
            v = m['versao']
            if not atualizacao.ha_versao_nova(m, ROOT):
                return {'estado': 'atual', 'versao': atual}
            if not manual and (self.adiada == v or self.ocupada()):
                return {'estado': 'adiada', 'versao': v}
            novidades = '\n'.join('• ' + n for n in m.get('novidades', []))
            ok = self.janela.create_confirmation_dialog(
                'Avulso IA — atualização disponível',
                f'A versão {v} está disponível (você usa a {atual}).\n\n{novidades}\n\n'
                'Atualizar agora? O Avulso IA vai recarregar a tela; termine antes o que estiver fazendo.',
            )
            if not ok:
                self.adiada = v
                return {'estado': 'adiada', 'versao': v}
            try:
                atualizacao.instalar(m, ROOT)
            except (atualizacao.ErroAtualizacao, OSError) as e:
                log.exception('Atualização para %s não instalada', v)
                return {'estado': 'erro', 'mensagem': f'A atualização não foi instalada ({e}). Nada foi alterado.'}
            log.info('Atualizado de %s para %s', atual, v)
            recarregar_icones_do_windows()
            self.janela.load_url(PAGE.as_uri())
            return {'estado': 'instalada', 'versao': v}
        finally:
            self.trava.release()

    def rodar(self, janela):
        self.janela = janela
        time.sleep(5)   # deixa a janela abrir antes da primeira consulta
        while True:
            self.verificar()
            time.sleep(INTERVALO_ATUALIZACAO)


class Api:
    """Funções que a página pode chamar (botão "Buscar atualização")."""

    def __init__(self, atualizador):
        self._atualizador = atualizador

    def buscar_atualizacao(self):
        return self._atualizador.verificar(manual=True)


def main():
    setup_logging()
    log.info('Iniciando o Avulso IA (%s)', ' '.join(sys.argv[1:]) or 'janela')

    if '--navegador' in sys.argv:
        open_in_browser()
        return

    try:
        import webview
    except ImportError:
        log.warning('pywebview não está instalado; usando o navegador')
        open_in_browser()
        return

    webview.settings['ALLOW_DOWNLOADS'] = True  # botão "Baixar" abre a janela "Salvar arquivo"
    webview.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER'] = True  # ex.: link de doação

    identidade_windows()
    atualizador = Atualizador()
    if PAGE.exists():
        # file:// em vez de caminho simples: assim o pywebview não sobe o servidor interno
        janela = webview.create_window(TITLE, url=PAGE.as_uri(), text_select=True, js_api=Api(atualizador), **WINDOW)
    else:
        janela = None
        log.error('Página não encontrada: %s', PAGE)
        webview.create_window(
            TITLE,
            html=error_page('Não encontrei a página do Avulso IA', f'Arquivo esperado:\n{PAGE}'),
            **WINDOW,
        )

    STORAGE_DIR.mkdir(exist_ok=True)
    try:
        webview.start(
            atualizador.rodar if janela else None,
            (janela,) if janela else None,
            private_mode=False,
            storage_path=str(STORAGE_DIR),
            icon=str(ICON) if ICON.exists() else None,
            localization=LOCALIZATION,
        )
    except Exception:
        # ex.: WebView2 ausente ou danificado; o navegador ainda funciona
        log.exception('Não foi possível abrir a janela; usando o navegador')
        open_in_browser()


if __name__ == '__main__':
    try:
        main()
    except Exception:
        log.critical('Erro inesperado:\n%s', traceback.format_exc())
        raise
