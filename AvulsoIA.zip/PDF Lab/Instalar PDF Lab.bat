<# : PDF Lab - instalador. Este arquivo e ao mesmo tempo .bat (estas linhas) e PowerShell (o resto).
@chcp 65001 >nul
@echo off
rem Tudo automatico e sem precisar de Python no Windows: baixa o Python portatil (python.org) para a pasta
rem python, baixa o PDF Lab mais novo publicado (tudo conferido pelo SHA-256), cria os atalhos e abre o app.
rem Arquivo em UTF-8 sem BOM e CRLF; acentos so nas mensagens.
setlocal
cd /d "%~dp0"
title PDF Lab - Instalação
echo.
echo  PDF Lab - Edição, organização e conversão de PDFs diretamente no seu computador
echo.
echo  A internet é usada só durante a instalação, para baixar os componentes do programa.
echo  Depois de instalado, o PDF Lab funciona sem internet.
echo.
set "PDFLAB_INSTALADOR=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& ([scriptblock]::Create([IO.File]::ReadAllText($env:PDFLAB_INSTALADOR)))"
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)
start "" "%~dp0python\pythonw.exe" "%~dp0pdflab.pyw"
timeout /t 6 >nul
exit /b 0
#>
param([switch]$SoFuncoes)

$ProgressPreference = 'SilentlyContinue'   # a barra de progresso deixa o download muito lento no PowerShell 5.1
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$app = Split-Path -Parent $env:PDFLAB_INSTALADOR
$py = Join-Path $app 'python\python.exe'

# so para os testes: servidores locais no lugar do GitHub e do python.org
# repositorio com o nome novo; enquanto ele nao existir com esse nome, o de nome antigo (Avulso IA)
$Bases = @('https://raw.githubusercontent.com/rla-devv/PDFLab-versoes/main/', 'https://raw.githubusercontent.com/rla-devv/avulsoIA-versoes/main/')
if ($env:PDFLAB_VERSOES_URL -like 'http://127.0.0.1:*') { $Bases = @($env:PDFLAB_VERSOES_URL -split ' ') }
$Versoes = $Bases[0]
$PythonUrl = 'https://www.python.org/ftp/python/3.14.8/'
if ($env:PDFLAB_PYTHON_URL -like 'http://127.0.0.1:*') { $PythonUrl = $env:PDFLAB_PYTHON_URL }
$Python = @{ Arquivo = 'python-3.14.8-embed-amd64.zip'; Pth = 'python314._pth'
             Sha256 = 'a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310' }

function Baixar([string]$Url, [string]$Destino, [string]$Erro) {
  try {
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destino -ErrorAction Stop
  } catch {
    Remove-Item $Destino -Force -ErrorAction SilentlyContinue
    throw $Erro
  }
}

function Sha256([string]$Arquivo) { return (Get-FileHash -Algorithm SHA256 $Arquivo).Hash.ToLower() }

function Instalar-Python {
  # Python portatil oficial: fica so dentro da pasta do app (nada e instalado no Windows)
  if (-not [Environment]::Is64BitOperatingSystem) { throw 'O PDF Lab precisa do Windows de 64 bits.' }
  Write-Host ' Baixando o Python portátil (python.org, cerca de 12 MB)...'
  $zip = Join-Path $env:TEMP $Python.Arquivo
  Baixar ($PythonUrl + $Python.Arquivo) $zip 'Não consegui baixar o Python. Confira se o computador está conectado à internet e rode este arquivo de novo.'
  if ((Sha256 $zip) -ne $Python.Sha256) {
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
    throw 'O Python baixado não confere com o original. Por segurança, nada foi instalado.'
  }
  $novo = Join-Path $app 'python.novo'
  Remove-Item $novo -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive -Path $zip -DestinationPath $novo -Force
  Remove-Item $zip -Force -ErrorAction SilentlyContinue
  # liga o "import site": sem isso o Python portatil nao enxerga os componentes da janela
  $pth = Join-Path $novo $Python.Pth
  (Get-Content $pth) -replace '^#\s*import site', 'import site' | Set-Content $pth -Encoding ASCII
  Remove-Item (Join-Path $app 'python') -Recurse -Force -ErrorAction SilentlyContinue
  Rename-Item $novo 'python'
}

function Baixar-Programa {
  # o pdflab.pyw da versao publicada mais nova; ele baixa o resto do app
  Write-Host ' Consultando a versão mais nova do PDF Lab...'
  $json = Join-Path $env:TEMP 'pdflab-atualizacao.json'
  $erro = 'Não consegui consultar a versão do PDF Lab. Confira se o computador está conectado à internet e rode este arquivo de novo.'
  $achou = $false
  foreach ($base in $Bases) {
    try { Baixar ($base + 'atualizacao.json?t=' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) $json $erro; $fonte = $base; $achou = $true; break } catch {}
  }
  if (-not $achou) { throw $erro }
  try { $m = [IO.File]::ReadAllText($json) | ConvertFrom-Json } catch { $m = $null }
  Remove-Item $json -Force -ErrorAction SilentlyContinue
  $a = $null
  if ($m) { $a = @($m.arquivos | Where-Object { $_.caminho -eq 'pdflab.pyw' }) | Select-Object -First 1 }
  if (-not $a -or "$($a.origem)" -notmatch '^(versoes|programa/\d+(\.\d+){1,3})/[A-Za-z0-9][A-Za-z0-9_.-]*$' -or
      "$($a.sha256)" -notmatch '^[0-9a-f]{64}$' -or -not ($a.tamanho -is [int] -or $a.tamanho -is [long])) {
    throw 'O aviso de versão publicado está com formato inesperado. Nada foi instalado.'
  }
  $novo = Join-Path $app 'pdflab.pyw.novo'
  Baixar ($fonte + $a.origem) $novo 'Não consegui baixar o PDF Lab. Confira se o computador está conectado à internet e rode este arquivo de novo.'
  if ((Get-Item $novo).Length -ne $a.tamanho -or (Sha256 $novo) -ne $a.sha256) {
    Remove-Item $novo -Force -ErrorAction SilentlyContinue
    throw 'O programa baixado não confere com o publicado. Por segurança, nada foi instalado.'
  }
  Move-Item $novo (Join-Path $app 'pdflab.pyw') -Force
}

function Rodar-Instalacao {
  # o proprio programa termina: pagina e icone, componentes da janela (pywebview) e atalhos
  & $py (Join-Path $app 'pdflab.pyw') --instalar
  if ($LASTEXITCODE -ne 0) { throw 'A instalação não terminou. Veja a mensagem acima.' }
}

function Testar-Internet {
  try {
    Invoke-WebRequest -UseBasicParsing -Method Head -Uri ($Versoes + 'atualizacao.json') -TimeoutSec 20 -ErrorAction Stop | Out-Null
    return $true
  } catch {
    return $null -ne $_.Exception.Response   # o servidor respondeu (mesmo com erro): ha internet
  }
}

function Instalar-App {
  if (-not (Testar-Internet)) {
    throw 'Sem conexão com a internet. A instalação precisa de internet para baixar os componentes do programa (só desta vez). Conecte o computador à internet e rode este arquivo de novo.'
  }
  if (-not (Test-Path $py)) { Instalar-Python }
  if (-not (Test-Path (Join-Path $app 'pdflab.pyw'))) { Baixar-Programa }
  Rodar-Instalacao
  Write-Host ''
  Write-Host ' Pronto! O PDF Lab está abrindo.'
  Write-Host " Para abrir depois, use o atalho 'Abrir PDF Lab' nesta pasta ou o atalho 'PDF Lab' na Área de"
  Write-Host ' Trabalho e no Menu Iniciar.'
}

if ($SoFuncoes) { return }   # os testes carregam so as funcoes

try {
  Instalar-App
  exit 0
} catch {
  Write-Host ''
  Write-Host " $($_.Exception.Message)"
  $pagina = Join-Path $app 'PDFLab-editorPDF.html'
  if (Test-Path $pagina) {
    Write-Host ' Enquanto isso, o PDF Lab vai abrir no navegador (funciona igual).'
    Start-Process $pagina
  }
  Write-Host ' Para tentar de novo, rode este arquivo outra vez.'
  exit 1
}
