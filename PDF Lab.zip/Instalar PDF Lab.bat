<# : PDF Lab - instalador. Este arquivo e ao mesmo tempo .bat (estas linhas) e PowerShell (o resto).
@chcp 65001 >nul
@echo off
rem Tudo automatico e sem precisar de Python no Windows: baixa o Python portatil (python.org) para a pasta
rem python, baixa o PDF Lab mais novo publicado (tudo conferido pelo SHA-256), cria os atalhos e abre o app.
rem Arquivo em UTF-8 sem BOM e CRLF; acentos so nas mensagens.
rem --na-pasta: uso interno; o proprio .bat se copiou para a pasta "PDF Lab" e roda de la (uma vez so)
setlocal
set "PDFLAB_NA_PASTA="
if /i "%~1"=="--na-pasta" set "PDFLAB_NA_PASTA=1"
cd /d "%~dp0"
title PDF Lab - Instalação
if defined PDFLAB_NA_PASTA goto sem_cabecalho
echo.
echo  PDF Lab - Edição, organização e conversão de PDFs diretamente no seu computador
echo.
echo  A internet é usada só durante a instalação, para baixar os componentes do programa.
echo  Depois de instalado, o PDF Lab funciona sem internet.
echo.
:sem_cabecalho
set "PDFLAB_INSTALADOR=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "& ([scriptblock]::Create([IO.File]::ReadAllText($env:PDFLAB_INSTALADOR)))"
rem codigo 3: a instalacao continuou (e terminou) pela copia deste arquivo na pasta "PDF Lab"
if errorlevel 3 exit /b 0
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)
start "" /max "%~dp0python\pythonw.exe" "%~dp0pdflab.pyw"
timeout /t 6 >nul
exit /b 0
#>
param([switch]$SoFuncoes)

$ProgressPreference = 'SilentlyContinue'   # a barra de progresso deixa o download muito lento no PowerShell 5.1
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$app = Split-Path -Parent $env:PDFLAB_INSTALADOR
$py = Join-Path $app 'python\python.exe'

# so para os testes: servidores locais no lugar do GitHub e do python.org
# repositorio com o nome novo; enquanto ele nao existir com esse nome, o de nome antigo (Avulso IA)
$Bases = @('https://raw.githubusercontent.com/rla-devv/PDFLab-versoes/main/', 'https://raw.githubusercontent.com/rla-devv/avulsoIA-versoes/main/')
if ($env:PDFLAB_VERSOES_URL -like 'http://127.0.0.1:*') { $Bases = @($env:PDFLAB_VERSOES_URL -split ' ') }
$Versoes = $Bases[0]
# Releases (1.21.9): o programa vem de la primeiro, porque o GitHub conta os downloads; se nao der, do repositorio
$Releases = 'https://github.com/rla-devv/PDFLab-versoes/releases/download/'
if ($env:PDFLAB_RELEASES_URL -like 'http://127.0.0.1:*') { $Releases = $env:PDFLAB_RELEASES_URL }
$PythonUrl = 'https://www.python.org/ftp/python/3.14.8/'
if ($env:PDFLAB_PYTHON_URL -like 'http://127.0.0.1:*') { $PythonUrl = $env:PDFLAB_PYTHON_URL }
$Python = @{ Arquivo = 'python-3.14.8-embed-amd64.zip'; Pth = 'python314._pth'
             Sha256 = 'a93abe456ab01bd96d7a085b3cdb6566b3063f4241360d114142fbdb07f0a310' }

function Baixar([string]$Url, [string]$Destino, [string]$Erro, [int]$Segundos = 600) {
  # com limite de tempo: uma conexao que trava nao deixa a janela parada para sempre
  try {
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destino -TimeoutSec $Segundos -ErrorAction Stop
  } catch {
    Remove-Item -LiteralPath $Destino -Force -ErrorAction SilentlyContinue
    throw $Erro
  }
}

function Sha256([string]$Arquivo) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $Arquivo).Hash.ToLower() }

function Instalar-Python {
  # Python portatil oficial: fica so dentro da pasta do app (nada e instalado no Windows)
  if (-not [Environment]::Is64BitOperatingSystem) { throw 'O PDF Lab precisa do Windows de 64 bits.' }
  Write-Host ' Baixando o Python portátil (python.org, cerca de 12 MB)...'
  $zip = Join-Path $env:TEMP $Python.Arquivo
  Baixar ($PythonUrl + $Python.Arquivo) $zip 'Não consegui baixar o Python. Confira se o computador está conectado à internet e rode este arquivo de novo.'
  if ((Sha256 $zip) -ne $Python.Sha256) {
    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
    throw 'O Python baixado não confere com o original. Por segurança, nada foi instalado.'
  }
  $novo = Join-Path $app 'python.novo'
  Remove-Item -LiteralPath $novo -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive -LiteralPath $zip -DestinationPath $novo -Force
  Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
  # liga o "import site": sem isso o Python portatil nao enxerga os componentes da janela
  $pth = Join-Path $novo $Python.Pth
  (Get-Content -LiteralPath $pth) -replace '^#\s*import site', 'import site' | Set-Content -LiteralPath $pth -Encoding ASCII
  Remove-Item -LiteralPath (Join-Path $app 'python') -Recurse -Force -ErrorAction SilentlyContinue
  Rename-Item -LiteralPath $novo 'python'
}

function Baixar-Programa {
  # o pdflab.pyw da versao publicada mais nova; ele baixa o resto do app
  Write-Host ' Consultando a versão mais nova do PDF Lab...'
  $json = Join-Path $env:TEMP 'pdflab-atualizacao.json'
  $erro = 'Não consegui consultar a versão do PDF Lab. Confira se o computador está conectado à internet e rode este arquivo de novo.'
  $achou = $false
  foreach ($base in $Bases) {
    try { Baixar ($base + 'atualizacao.json?t=' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()) $json $erro 60; $fonte = $base; $achou = $true; break } catch {}
  }
  if (-not $achou) { throw $erro }
  try { $m = [IO.File]::ReadAllText($json) | ConvertFrom-Json } catch { $m = $null }
  Remove-Item -LiteralPath $json -Force -ErrorAction SilentlyContinue
  $a = $null
  if ($m) { $a = @($m.arquivos | Where-Object { $_.caminho -eq 'pdflab.pyw' }) | Select-Object -First 1 }
  if (-not $a -or "$($a.origem)" -notmatch '^(versoes|programa/\d+(\.\d+){1,3})/[A-Za-z0-9][A-Za-z0-9_.-]*$' -or
      "$($a.sha256)" -notmatch '^[0-9a-f]{64}$' -or -not ($a.tamanho -is [int] -or $a.tamanho -is [long])) {
    throw 'O aviso de versão publicado está com formato inesperado. Nada foi instalado.'
  }
  # baixa na pasta temporaria (o -OutFile do PowerShell 5.1 le [ ] do nome da pasta como curinga) e so entao move
  $novo = Join-Path $env:TEMP 'pdflab.pyw.novo'
  $ok = $false
  if ("$($a.release)" -match '^v\d+(\.\d+){1,3}/[A-Za-z0-9][A-Za-z0-9_.-]*$') {
    try {
      Baixar ($Releases + $a.release) $novo 'release' 120
      $ok = (Get-Item -LiteralPath $novo).Length -eq $a.tamanho -and (Sha256 $novo) -eq $a.sha256
    } catch { }
  }
  if (-not $ok) {
    Baixar ($fonte + $a.origem) $novo 'Não consegui baixar o PDF Lab. Confira se o computador está conectado à internet e rode este arquivo de novo.'
  }
  if ((Get-Item -LiteralPath $novo).Length -ne $a.tamanho -or (Sha256 $novo) -ne $a.sha256) {
    Remove-Item -LiteralPath $novo -Force -ErrorAction SilentlyContinue
    throw 'O programa baixado não confere com o publicado. Por segurança, nada foi instalado.'
  }
  Move-Item -LiteralPath $novo -Destination (Join-Path $app 'pdflab.pyw') -Force
}

function Rodar-Instalacao {
  # o proprio programa termina: pagina e icone, componentes da janela (pywebview) e atalhos
  & $py (Join-Path $app 'pdflab.pyw') --instalar
  if ($LASTEXITCODE -ne 0) { throw 'A instalação não terminou. Veja a mensagem acima.' }
}

function Testar-Internet {
  try {
    Invoke-WebRequest -UseBasicParsing -Method Head -Uri ($Versoes + 'atualizacao.json') -TimeoutSec 20 -ErrorAction Stop | Out-Null
    return $true
  } catch {
    return $null -ne $_.Exception.Response   # o servidor respondeu (mesmo com erro): ha internet
  }
}

# Onde instalar (1.21.12, padrao dos apps RLA.dev, pedido do dono): sempre em C:\rla-lab\PDF Lab, para nao ficar
# espalhado pela pasta Downloads; os atalhos (pasta do app, Area de Trabalho e Menu Iniciar) apontam para la.
#  - Rodado de dentro de uma instalacao (tem o pdflab.pyw ou o python): fica nela (atualiza/repara). Instalacoes
#    antigas em outras pastas continuam onde estao.
#  - Senao: C:\rla-lab\PDF Lab (o Windows deixa qualquer usuario criar pasta na raiz do C:, sem administrador); se
#    nao der (computador com regra que proibe), %LOCALAPPDATA%\Programs\rla-lab\PDF Lab.
# Ele se copia para a pasta escolhida, roda a copia com --na-pasta (nesta mesma janela) e sai com o codigo 3.
$NomeApp = 'PDF Lab'
$RlaLab = Join-Path ("$env:SystemDrive" + '\') 'rla-lab'
if ($env:PDFLAB_RLA_LAB) { $RlaLab = $env:PDFLAB_RLA_LAB }   # testes

function Gravavel([string]$Dir) {
  try {
    New-Item -ItemType Directory -Force -Path $Dir | Out-Null
    $teste = Join-Path $Dir '.teste-de-gravacao'
    [IO.File]::WriteAllText($teste, '')
    Remove-Item -Force -LiteralPath $teste
    return $true
  } catch { return $false }
}

function Mesma-Pasta([string]$A, [string]$B) {
  return $A.TrimEnd('\', '/') -eq $B.TrimEnd('\', '/')   # -eq do PowerShell ignora maiusculas, como o Windows
}

function Pasta-Destino {
  # $null = instala aqui; senao, a pasta onde instalar
  if ($env:PDFLAB_NA_PASTA -eq '1') { return $null }
  foreach ($f in @('pdflab.pyw', 'avulsoia.pyw', 'python\python.exe')) {
    if (Test-Path -LiteralPath (Join-Path $app $f)) { return $null }   # ja instalado aqui: atualiza/repara
  }
  $padrao = Join-Path $RlaLab $NomeApp
  if (Mesma-Pasta $app $padrao) { return $null }
  if (Gravavel $padrao) { return $padrao }
  if ($env:LOCALAPPDATA) {   # sem permissao na raiz do C:
    $reserva = Join-Path $env:LOCALAPPDATA "Programs\rla-lab\$NomeApp"
    if (Mesma-Pasta $app $reserva) { return $null }
    if (Gravavel $reserva) { return $reserva }
  }
  throw "Não foi possível criar a pasta $padrao. Crie essa pasta, ponha este arquivo nela e abra-o de lá."
}

function Seguir-Em([string]$Dir) {
  $novo = Join-Path $Dir 'Instalar PDF Lab.bat'
  Copy-Item -Force -LiteralPath $env:PDFLAB_INSTALADOR -Destination $novo
  Write-Host ' O PDF Lab vai ser instalado na pasta:'
  Write-Host " $Dir" -ForegroundColor Cyan
  Write-Host ''
  # a copia roda nesta mesma janela; quando ela terminar, este .bat sai sem fazer mais nada. Espera so a copia: o
  # opcao de espera do proprio Start-Process aguarda tambem o que ela abre (o proprio app), e a janela preta ficava aberta (1.21.14)
  $copia = Start-Process -FilePath $env:ComSpec -ArgumentList "/c `"`"$novo`" --na-pasta`"" -NoNewWindow -PassThru
  $copia.WaitForExit()
  exit 3
}

function Instalar-App {
  if (-not (Testar-Internet)) {
    throw 'Sem conexão com a internet. A instalação precisa de internet para baixar os componentes do programa (só desta vez). Conecte o computador à internet e rode este arquivo de novo.'
  }
  if (-not (Test-Path -LiteralPath $py)) { Instalar-Python }
  if (-not (Test-Path -LiteralPath (Join-Path $app 'pdflab.pyw'))) { Baixar-Programa }
  Rodar-Instalacao
  Write-Host ''
  Write-Host ' Pronto! O PDF Lab está abrindo.'
  Write-Host " Para abrir depois, use o atalho 'PDF Lab' na Área de Trabalho e no Menu Iniciar, ou o atalho"
  Write-Host " 'Abrir PDF Lab' na pasta do programa: $app"
}

if ($SoFuncoes) { return }   # os testes carregam so as funcoes

try {
  $destino = Pasta-Destino
  if ($destino) { Seguir-Em $destino }
  Instalar-App
  exit 0
} catch {
  Write-Host ''
  Write-Host " $($_.Exception.Message)"
  $pagina = Join-Path $app 'PDFLab-editorPDF.html'
  if (Test-Path -LiteralPath $pagina) {
    Write-Host ' Enquanto isso, o PDF Lab vai abrir no navegador (funciona igual).'
    Invoke-Item -LiteralPath $pagina
  }
  Write-Host ' Para tentar de novo, rode este arquivo outra vez.'
  exit 1
}
